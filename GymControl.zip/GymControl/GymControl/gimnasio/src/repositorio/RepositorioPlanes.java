package repositorio;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import modelo.Plan;

public class RepositorioPlanes extends RepositorioArchivo {

    public RepositorioPlanes(String archivo) {
        super(archivo);
    }

    public void guardarTodos(List<Plan> planes) throws IOException {
        List<String> lineas = new ArrayList<>();
        for (Plan p : planes) {
            lineas.add(p.convertirALineaArchivo());
        }
        escribirLineas(lineas);
    }

    public ArrayList<Plan> leerTodos() throws IOException {
        ArrayList<Plan> planes = new ArrayList<>();

        for (String linea : leerLineas()) {
            try {
                planes.add(Plan.crearDesdeLinea(linea));
            } catch (RuntimeException e) {
                contarLineaInvalida();
            }
        }
        return planes;
    }
}
