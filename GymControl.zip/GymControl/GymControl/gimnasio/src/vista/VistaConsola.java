package vista;

import java.util.Scanner;

public class VistaConsola {
    private Scanner sc;

    public VistaConsola() {
        this.sc = new Scanner(System.in);
    }

    public void mostrarMenu() {
        System.out.println();
        System.out.println("========== GYMCONTROL ==========");
        System.out.println("1. Socios");
        System.out.println("2. Planes");
        System.out.println("3. Membresias");
        System.out.println("4. Asistencias");
        System.out.println("5. Entrenadores");
        System.out.println("0. Salir");
    }

    public void mostrarSubmenu(String titulo, String[] opciones) {
        System.out.println();
        System.out.println("========== " + titulo.toUpperCase() + " ==========");
        for (int i = 0; i < opciones.length; i++) {
            System.out.println((i + 1) + ". " + opciones[i]);
        }
        System.out.println("0. Volver");
    }

    public void mostrarMensaje(String mensaje) {
        System.out.println(mensaje);
    }

    private String leerLinea() {
        if (sc.hasNextLine() == false) {
            System.out.println();
            System.out.println("Se cerro la entrada de datos. Fin del programa.");
            System.exit(0);
        }
        return sc.nextLine().trim();
    }

    public String leerTexto(String mensaje) {
        System.out.print(mensaje);
        String texto = leerLinea();
        return texto.replace(";", ",");
    }

    public int leerEntero(String mensaje) {
        int numero = 0;
        boolean valido = false;
        while (valido == false) {
            System.out.print(mensaje);
            try {
                numero = Integer.parseInt(leerLinea());
                valido = true;
            } catch (NumberFormatException e) {
                System.out.println("Hay que ingresar un numero entero.");
            }
        }
        return numero;
    }

    public double leerDecimal(String mensaje) {
        double numero = 0;
        boolean valido = false;
        while (valido == false) {
            System.out.print(mensaje);
            String texto = leerLinea().replace(",", ".");
            if (texto.matches("[0-9]+([.][0-9]+)?")) {
                numero = Double.parseDouble(texto);
                valido = true;
            } else {
                System.out.println("Hay que ingresar un numero, por ejemplo 18 o 18.5");
            }
        }
        return numero;
    }

    public int elegirPosicion(String titulo, String[] opciones) {
        System.out.println(titulo);
        for (int i = 0; i < opciones.length; i++) {
            System.out.println((i + 1) + ". " + opciones[i]);
        }
        int numero = leerEntero("Opcion: ");
        while (numero < 1 || numero > opciones.length) {
            System.out.println("Opcion invalida.");
            numero = leerEntero("Opcion: ");
        }
        return numero - 1;
    }

    public String elegirDeLista(String titulo, String[] opciones) {
        return opciones[elegirPosicion(titulo, opciones)];
    }
}
